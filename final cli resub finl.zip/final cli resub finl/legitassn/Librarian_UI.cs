﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace legitassn
{
    public class Librarian_UI
    {
        // Librarian login function
        public static Librarian LibrarianLogin()
        {
            Console.WriteLine("\n===Librarian Login===");

            Console.Write("Enter Your ID: ");
            string username = Console.ReadLine();

            Console.Write("Enter Your Password: ");
            string password = Console.ReadLine();

            Librarian librarian = ValidateLibrarianLogin(username, password);

            if (librarian != null)
            {
                LibrarianMenu(librarian);
                return librarian;
            }
            else
            {
                Console.WriteLine("Invalid username or password.. Please try again");
                Program.MainMenu();
                return null;
            }
        }
        // Validate librarian login credentials
        public static Librarian ValidateLibrarianLogin(string libID, string libPwd)
        {
            return Library.librarians.Find(l => l.LibrarianID == libID && l.LibrarianPwd == libPwd);
        }
        // Display librarian menu
        public static void LibrarianMenu(Librarian librarian)
        {
            int menuchoice = 0;

            try
            {
                Console.WriteLine("Welcome to the Library, {0}!", librarian.Name);
                Console.WriteLine("===============================================");
                Console.WriteLine("Enter the corresponding number to use the function:");
                Console.WriteLine("1. View Details");
                Console.WriteLine("2. Sign Up Member");
                Console.WriteLine("3. View Members");
                Console.WriteLine("4. View Member Details");
                Console.WriteLine("5. Remove Member");
                Console.WriteLine("6. View Books");
                Console.WriteLine("7. Add Book");
                Console.WriteLine("8. Remove Book");
                Console.WriteLine("9. Extend Loan for Member");
                Console.WriteLine("10. Change Password");
                Console.WriteLine("11. Exit");
                Console.WriteLine("===============================================");
                Console.Write("Your choice: ");
                menuchoice = Convert.ToInt32(Console.ReadLine());
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                Console.WriteLine("Exceptions Handled");

                ProcessLibrarianMenuChoice(menuchoice, librarian);
            }
        }
        // Process librarian menu choice
        private static void ProcessLibrarianMenuChoice(int choice, Librarian librarian)
        {
            switch (choice)
            {
                case 1:
                    librarian.ToString();
                    LibrarianMenu(librarian);
                    break;
                case 2:
                    MemberSignUp();
                    LibrarianMenu(librarian);
                    break;
                case 3:
                    ViewMembers();
                    LibrarianMenu(librarian);
                    break;
                case 4:
                    Librarian.ViewMember();
                    LibrarianMenu(librarian);
                    break;
                case 5:
                    RemoveMember();
                    LibrarianMenu(librarian);
                    break;
                case 6:
                    Librarian.ViewBooks();
                    LibrarianMenu(librarian);
                    break;
                case 7:
                    AddBook();
                    LibrarianMenu(librarian);
                    break;
                case 8:
                    Librarian.ViewBooks();
                    RemoveBook();
                    LibrarianMenu(librarian);
                    break;
                case 9:
                    LoanExtension();
                    LibrarianMenu(librarian);
                    break;
                case 10:
                    librarian.ChangePassword(librarian);
                    LibrarianMenu(librarian);
                    break;
                case 11:
                    Console.WriteLine("Thank your for using this system, {0}, Come Again!!!", librarian.Name);
                    Program.MainMenu();
                    break;
                default:
                    Console.WriteLine("Invalid choice");
                    LibrarianMenu(librarian);
                    break;
            }
        }
        // Member sign-up function
        public static void MemberSignUp()
        {
            // Prompting for member information
            Console.WriteLine("=== Member Sign Up ===");
            Console.Write("Enter Member ID: ");
            string memberId = Console.ReadLine();
            Member member = Library.members.Find(m => m.memID == memberId);

            if (member == null)
            {
                // Gathering member details and adding to the library
                Console.Write("Enter Member Name: ");
                string memberName = Console.ReadLine();
                Console.Write("Enter Member Date of Birth (yyyy-MM-dd): ");
                DateTime memberDOB = DateTime.Parse(Console.ReadLine());
                Console.Write("Enter Member Address: ");
                string memberAddress = Console.ReadLine();
                Library library = new Library();
                library.AddMember(memberId, "passwd", memberName, memberDOB, memberAddress);
                Console.WriteLine("Member Signed Up Successfully!");
            }
            else
            {
                // Informing that the member ID already exists
                Console.WriteLine("Member ID already exists. Please enter a different ID.");
            }
        }
        // View all members function
        private static void ViewMembers()
        {
            // Displaying a formatted list of all members
            Console.WriteLine("=== View Members ===");
            Console.WriteLine("-----------------------------------------------------------");
            Console.WriteLine("| Member ID | Member Name     | Date of Birth | Member Address | Loans |");
            Console.WriteLine("-----------------------------------------------------------");
            foreach (Member member in Library.members)
            {
                Console.WriteLine($"| {member.memID,-10} | {member.Name,-15} | {member.DOB.ToShortDateString(),-13} | {member.Address,-15} | {member.Loans.Count,-5} |");
            }
            Console.WriteLine("-----------------------------------------------------------");
        }

        // Remove member function
        private static void RemoveMember()
        {
            // Displaying members and prompting for ID to remove
            Console.WriteLine("=== Remove Member ===");
            ViewMembers();
            Console.Write("Enter ID of Member to Remove: ");
            string memberId = Console.ReadLine();
            Library library = new Library();
            library.RemoveMember(memberId);
        }
        // Loan extension function
        public static void LoanExtension()
        {
            // Extending the due date of a member's loan
            Console.WriteLine("=== Loan Extension ===");
            Console.Write("Enter ID of Member to View Their Loans: ");
            String memberId = Console.ReadLine();
            Member member = Library.members.Find(m => m.memID == memberId);

            if (member.Loans.Count == 0)
            {
                // Informing if the member has no loans
                Console.WriteLine("No Loans For this Member");
            }
            else
            {
                // Prompting for loan ID and extending due date
                Console.WriteLine("Enter Loan ID of Member: ");
                member.ViewLoanList(member);
                string loanId = Console.ReadLine();
                Loan loan = member.Loans.Find(l => l.LoanID == loanId);
                loan.DueDate = loan.DueDate.AddDays(7);
                Console.WriteLine("Loan has been extended by 7 days");
            }
        }

        // Add book function
        private static void AddBook()
        {
            // Adding a new book to the library
            Console.WriteLine("=== Add Book ===");
            Console.Write("Enter ISBN of Book: ");
            string isbn = Console.ReadLine();
            Console.Write("Enter Title of Book: ");
            string title = Console.ReadLine();
            Console.Write("Enter Author of Book: ");
            string author = Console.ReadLine();
            Program.library.AddBook($"B{Library.books.Count + 1}", isbn, title, author);
            Console.WriteLine("{0} by {1} has been added to the library successfully", title, author);
        }

        // Remove book function
        private static void RemoveBook()
        {
            // Removing a book from the library
            Console.WriteLine("=== Remove Book ===");
            Console.Write("Enter ID of Book you want to remove: ");
            string bookid = Console.ReadLine();
            Library library = new Library();
            library.RemoveBook(bookid);
        }

    }
}

