﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace legitassn
{
    public class Librarian : Person
    {
        public string LibrarianID { get; set; }
        public string LibrarianPwd { get; set; }
        public double SalaryRate { get; set; }
        public int WorkHours { get; set; }

        public Librarian(string librarianID, string librarianpwd, string name, DateTime dateOfBirth, string address, double salaryRate, int workHours)
        : base(name, dateOfBirth, address)
        {
            LibrarianPwd = librarianpwd;
            LibrarianID = librarianID;
            SalaryRate = salaryRate;
            WorkHours = workHours;
        }
        public override string ToString()
        {
            return $"Librarian Details: EmployeeID: {LibrarianID}, Salary Rate: ${SalaryRate}/hour, Work Hours: {WorkHours} hours";
        }
        private void calculateSalary(Librarian librarian)
        {
            double salary = librarian.SalaryRate * librarian.WorkHours;
            Console.WriteLine($"Calculated Salary: ${salary}");
        }
         // Static method to view details and loans of a member by entering their ID
        public static void ViewMember()
        {
            Console.WriteLine("Enter Member ID:");
            string memID = Console.ReadLine();
            Member member = Library.members.Find(m => m.memID == memID);

            if (member == null)
            {
                Console.WriteLine("Member Does Not Exist");
            }
            else
            {
                member.ToString();
                Console.WriteLine("Loans of {0}", member.Name);
                member.ViewLoanList(member);
            }

        }
        // Static method to view details of all books in the library
        public static void ViewBooks()
        {
            Console.WriteLine("All Books");
            Console.WriteLine("-------------------------------------------------------------");
            Console.WriteLine("|   Book ID   |      Title       |    Author    |     ISBN     |     Availability     |");
            Console.WriteLine("-------------------------------------------------------------");

            foreach (Book book in Library.books)
            {

                Console.WriteLine($"| {book.BookID,-13} | {book.Title,-25} | {book.Author,-18} | {book.ISBN,-15} | {book.Availability,-10}");
            }
        }
        // Method to change the password of the librarian
        public void ChangePassword(Librarian librarian)
        {
            Console.WriteLine("Enter Your Current Password:");
            string curntpwd = Console.ReadLine();

            if (curntpwd == librarian.LibrarianPwd)
            {
                Console.WriteLine("Enter Your New Password:");
                string newpwd = Console.ReadLine();
                librarian.LibrarianPwd = newpwd;
                Console.WriteLine("Your Password Has Been Changed");
            }
            else
            {
                Console.WriteLine("Password Invalid");
            }
        }
    }
}
