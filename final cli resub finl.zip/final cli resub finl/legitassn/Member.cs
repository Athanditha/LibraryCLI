﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.Remoting.Services;
using System.Text;
using System.Threading.Tasks;

namespace legitassn
{
    public class Member : Person
    {
        // Properties for Member details
        public string memID { get; set; }
        public string password { get; set; }
        public double penaltyfee { get; set; }
        public List<Loan> Loans { get; set; }

        // Constructor to initialize Member object with details and borrowed items
        public Member(string memID, string password, string name, DateTime dateofBirth, string address, List<Loan> Borrowed) : base(name, dateofBirth, address)
        {
            this.memID = memID;
            this.password = password;
            this.penaltyfee = penaltyfee;
            this.Loans = Borrowed ?? new List<Loan>();
        }

        // Method to view available books in the library
        public void ViewAvailableBooks()
        {
            Console.WriteLine("-------------------------------------------------------------");
            Console.WriteLine("|   Book ID   |      Title       |    Author    |     ISBN     |");
            Console.WriteLine("-------------------------------------------------------------");

            foreach (Book book in Library.books)
            {
                if (book.Availability)
                {
                    Console.WriteLine($"| {book.BookID,-13} | {book.Title,-25} | {book.Author,-18} | {book.ISBN,-15} |");
                }
            }
        }

        // Method to view the list of loans for the member
        public void ViewLoanList(Member member)
        {
            Console.WriteLine("Loans for Member {0}:", member.memID);
            Console.WriteLine("Loans Count: {0}:", member.Loans.Count);
            foreach (Loan loan in Loans)
            {
                Console.WriteLine("---------------------------------------------------------------------------------");
                Console.WriteLine($"Loan ID: {loan.LoanID}");
                Console.WriteLine($"Book ID: {loan.BorrowedBookID.BookID}");
                Console.WriteLine($"Book Title: {loan.BorrowedBookID.Title}");
                Console.WriteLine($"Due Date: {loan.DueDate.ToShortDateString()}");
                Console.WriteLine("---------------------------------------------------------------------------------");
            }
        }

        // Method to change the password of the member
        public void ChangePassword(Member member)
        {
            Console.WriteLine("Enter Your Current Password:");
            string currentPassword = Console.ReadLine();

            if (currentPassword == member.password)
            {
                Console.WriteLine("Enter Your New Password:");
                string newPassword = Console.ReadLine();
                member.password = newPassword;
                Console.WriteLine("Your Password Has Been Changed");
            }
            else
            {
                Console.WriteLine("Password Invalid");
            }
        }

        // Method to borrow a book for the member
        public void BorrowBook(string memberId, string bookId)
        {
            // Find the book and member based on the provided IDs
            Book book = Library.books.Find(b => b.BookID == bookId);
            Member member = Library.members.Find(m => m.memID == memberId);

            if (book == null)
            {
                Console.WriteLine("Book not found. Please add the book first.");
                return;
            }

            if (!book.CheckBookAvailability())
            {
                Console.WriteLine("Book is not available for borrowing.");
                return;
            }
            else
            {
                // Create a new loan and add it to the member's loans list
                Loan newLoan = new Loan($"L{Loans.Count + 1}", member.memID, book.BookID, DateTime.Now.AddDays(14));
                Loans.Add(newLoan);

                // Update book availability and save loans
                book.Availability = false;
                Library.loans.Add(newLoan);

                Console.WriteLine("Book Borrowed Successfully!");
            }

            // Save the loans data
            Library library = new Library();
            library.SaveLoans();
        }

        // Method to return a book for the member
        public void ReturnBook(string memberID, string bookId)
        {
            // Find the member and loan based on the provided IDs
            Member member = Library.members.Find(m => m.memID == memberID);
            Loan loan = member.Loans.Find(l => l.BorrowedBookID.BookID == bookId);

            if (loan == null)
            {
                Console.WriteLine("Loan not found. Cannot return the book.");
                return;
            }
            else
            {
                // Update book availability and remove the loan from the member's loans list
                Book book = loan.BorrowedBookID;
                book.Availability = true;

                Loans.Remove(loan);
                Library.loans.Remove(loan);
                Console.WriteLine("Book Returned Successfully!");
            }

            // Save the loans data
            Library library = new Library();
            library.SaveLoans();
        }

        // Method to calculate and display penalty for a specific loan
        public void GetPenalty(Member member, string loanID)
        {
            Loan loan = member.Loans.Find(l => l.LoanID == loanID);

            if (loan == null)
            {
                Console.WriteLine("Loan not found. Cannot calculate penalty.");
                return;
            }

            DateTime currentDate = DateTime.Now;
            DateTime dueDate = loan.DueDate;

            if (currentDate > dueDate)
            {
                int overdueDays = (int)(currentDate - dueDate).TotalDays;
                double penaltyAmount = overdueDays * 50;
                member.penaltyfee += penaltyAmount;

                Console.WriteLine($"Penalty calculated for overdue book: ${penaltyAmount}");
                Console.WriteLine($"Total penalty for {overdueDays} days overdue: ${member.penaltyfee}");
            }
            else
            {
                Console.WriteLine("The book is not overdue. No penalty is applied.");
            }
        }

        // Override ToString method to display member details
        public override string ToString()
        {
            Console.WriteLine("-------------------------------------------------------------");
            Console.WriteLine($"Member ID: {memID}");
            Console.WriteLine($"Member Name: {Name}");
            Console.WriteLine($"Date of Birth: {DOB.ToShortDateString()}");
            Console.WriteLine($"Member Address: {Address}");
            Console.WriteLine("-------------------------------------------------------------");
            return base.Name;
        }
    }
}
