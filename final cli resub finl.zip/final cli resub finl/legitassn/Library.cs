﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace legitassn
{
    public class Library
    {
        // Lists to store members, librarians, books, and loans
        public static List<Member> members = new List<Member>();
        public static List<Librarian> librarians = new List<Librarian>();
        public static List<Book> books = new List<Book>();
        public static List<Loan> loans = new List<Loan>();

        // File names for data persistence
        private const string MemberFileName = "memberdetails.txt";
        private const string LibrarianFileName = "librariandetails.txt";
        private const string BookFileName = "bookdetails.txt";
        private const string LoanFileName = "loandetails.txt";


        // Add a new member to the library
        public void AddMember(string memberId, string memberpwd, string memberName, DateTime memberDOB, string memberAddress)
        {
            Member newMember = new Member(memberId, memberpwd, memberName, memberDOB, memberAddress, new List<Loan>());
            members.Add(newMember);
            SaveMembers();
        }

        // Remove a member from the library
        public void RemoveMember(string memberId)
        {
            Member member = Library.members.Find(m => m.memID == memberId);
            if (member != null)
            {
                members.Remove(member);
                Console.WriteLine("Member Removed Successfully");
            }
            else
            {
                Console.WriteLine("Member Not Found");
            }
            SaveMembers();
        }

        // Add a new librarian to the library
        public void AddLibrarian(string libId, string libPwd, string libName, DateTime libDOB, string libAddress)
        {
            Librarian newLibrarian = new Librarian(libId, libPwd, libName, libDOB, libAddress, 10.00, 8);
            librarians.Add(newLibrarian);
            SaveLibrarians();
        }

        // Add a new book to the library
        public void AddBook(string bookId, string isbn, string title, string author)
        {
            Book newBook = new Book(bookId, isbn, title, author, true);
            books.Add(newBook);
            SaveBooks();
        }

        // Remove a book from the library
        public void RemoveBook(string bookId)
        {
            Book book = books.Find(b => b.BookID == bookId);

            if (book == null)
            {
                Console.WriteLine("Book not found. Cannot remove the book.");
                return;
            }

            if (!book.CheckBookAvailability())
            {
                Console.WriteLine("Book should be available within the library for removal. Try again once the book is returned by the borrower.");
                return;
            }

            books.Remove(book);
            Console.WriteLine("Book Removed Successfully!");
            SaveBooks();
        }

        //Save Members

        public void SaveMembers()
        {
            string filepath = Path.Combine(Directory.GetCurrentDirectory(), MemberFileName);
            using (StreamWriter writer = new StreamWriter(filepath))
            {
                foreach (Member member in members)
                {
                    writer.WriteLine($"{member.memID},{member.password},{member.Name},{member.DOB},{member.Address}");
                }
            }
        }

        //Load Members
        public List<Member> LoadMembers()
        {
            List<Member> loadedMembers = new List<Member>();
            string filepath = Path.Combine(Directory.GetCurrentDirectory(), MemberFileName);
            if (File.Exists(filepath))
            {
                string[] lines = File.ReadAllLines(filepath);

                foreach (string line in lines)
                {
                    string[] data = line.Split(',');

                    if (data.Length == 5)
                    {
                        string memID = data[0];
                        string password = data[1];
                        string name = data[2];
                        DateTime dob = DateTime.Parse(data[3]);
                        string address = data[4];

                        Member member = new Member(memID, password, name, dob, address, new List<Loan>());
                        members.Add(member);
                    }
                }
            }

            return members;
        }
        // Save Books to a file
        public void SaveBooks()
        {
            string filepath = Path.Combine(Directory.GetCurrentDirectory(), BookFileName);
            using (StreamWriter writer = new StreamWriter(filepath))
            {
                foreach (Book book in books)
                {
                    writer.WriteLine($"{book.BookID},{book.ISBN},{book.Title},{book.Author},{book.Availability}");
                }
            }
        }
        // Load Books from a file
        public List<Book> LoadBooks()
        {
            List<Book> loadedBooks = new List<Book>();
            string filepath = Path.Combine(Directory.GetCurrentDirectory(), BookFileName);
            if (File.Exists(filepath))
            {
                string[] lines = File.ReadAllLines(filepath);

                foreach (string line in lines)
                {
                    string[] bookData = line.Split(',');

                    if (bookData.Length == 5)
                    {
                        string bookID = bookData[0];
                        string isbn = bookData[1];
                        string title = bookData[2];
                        string author = bookData[3];
                        bool availability = bool.Parse(bookData[4]);

                        Book book = new Book(bookID, isbn, title, author, availability);
                        books.Add(book);
                    }
                }
            }
            return books;
        }
        // Save Librarians to a file
        public void SaveLibrarians()
        {
            string filepath = Path.Combine(Directory.GetCurrentDirectory(), LibrarianFileName);
            using (StreamWriter writer = new StreamWriter(filepath))
            {
                foreach (Librarian librarian in librarians)
                {
                    writer.WriteLine($"{librarian.LibrarianID},{librarian.LibrarianPwd},{librarian.Name},{librarian.DOB},{librarian.Address},{librarian.SalaryRate},{librarian.WorkHours}");
                }
            }
        }
        // Load Librarians from a file
        public List<Librarian> LoadLibrarians()
        {
            string filepath = Path.Combine(Directory.GetCurrentDirectory(), LibrarianFileName);
            if (File.Exists(filepath))
            {
                string[] lines = File.ReadAllLines(filepath);

                foreach (string line in lines)
                {
                    string[] data = line.Split(',');

                    if (data.Length == 7)
                    {
                        string librarianId = data[0];
                        string librarianPwd = data[1];
                        string name = data[2];
                        DateTime dateOfBirth = DateTime.Parse(data[3]);
                        string address = data[4];
                        double salaryRate = double.Parse(data[5]);
                        int workHours = int.Parse(data[6]);

                        Librarian librarian = new Librarian(librarianId, librarianPwd, name, dateOfBirth, address, salaryRate, workHours);
                        librarians.Add(librarian);
                    }
                }
            }
            return librarians;
        }
        // Save Loans to a file
        public void SaveLoans()
        {
            string filepath = Path.Combine(Directory.GetCurrentDirectory(), LoanFileName);
            using (StreamWriter writer = new StreamWriter(filepath))
            {
                foreach (Loan loan in loans)
                {
                    writer.WriteLine($"{loan.LoanID},{loan.BorrowedMember.memID},{loan.BorrowedBookID.BookID},{loan.DueDate}");
                }
            }
        }
        // Load Loans from a file
        public List<Loan> LoadLoans() 
        {
            string filepath = Path.Combine(Directory.GetCurrentDirectory(), LoanFileName);
            if (File.Exists(filepath))
            {
                string[] lines = File.ReadAllLines(filepath);

                foreach (string line in lines)
                {
                    string[] data = line.Split(',');

                    if (data.Length == 7)
                    {
                        string loanId = data[0];
                        string MemberId = data[1];
                        string BookId = data[2];
                        DateTime DueDate = DateTime.Parse(data[3]);

                        Loan loan = new Loan(loanId, MemberId, BookId, DueDate);
                        loans.Add(loan);

                        Member member = members.Find(m => m.memID == MemberId);
                        if (member != null)
                        {
                            Loan memloan = new Loan(loanId,MemberId, BookId, DueDate);
                            member.Loans.Add(loan);
                            loans.Add(loan);
                        }
                        else
                        {
                            Console.WriteLine($"Member '{MemberId}' not found for loan '{loanId}'.");
                        }

                    }
                }
            }
            return loans;
        }


        // Save all data to respective files
        public void SaveData()
        {
            SaveBooks();
            SaveLibrarians();
            SaveMembers();
            SaveLoans();
            
        }
        // Save all data to respective files
        public void LoadData()
        {
            LoadBooks();
            LoadLibrarians();
            LoadMembers();
            LoadLoans();

        }
    }


}





