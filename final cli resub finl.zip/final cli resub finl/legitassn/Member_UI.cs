﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace legitassn
{
    public class Member_UI
    {
        // Member login function
        public static Member MemberLogin()
        {
            Console.WriteLine("\n=== Member Login ===");

            Console.Write("Enter Your Username: ");
            string username = Console.ReadLine();

            Console.Write("Enter Your Password: ");
            string password = Console.ReadLine();
            // Validating member login credentials
            Member member = ValidateMemberLogin(username, password);

            if (member != null)
            {
                // If login is successful, display member menu
                Console.WriteLine("\nLogin successful. Welcome, {0}!", member.Name);
                MemberMenu(member);
                return member;
            }
            else
            {
                // If login fails, show error and return to main menu
                Console.WriteLine("\nInvalid username or password. Please try again.");
                Program.MainMenu();
                return null;
            }
        }
        // Validate member login credentials
        public static Member ValidateMemberLogin(string memID, string memPwd)
        {
            return Library.members.Find(m => m.memID == memID && m.password == memPwd);
        }
        // Display member menu
        public static void MemberMenu(Member member)
        {
            int menuchoice = 0;

            try
            {
                // Displaying member menu options
                Console.WriteLine("Welcome to the Library, {0}!!!", member.Name);
                Console.WriteLine("--------------------------------------------------");
                Console.WriteLine("Enter the corresponding number to use the function:");
                Console.WriteLine("1. View Details");
                Console.WriteLine("2. View Available Books");
                Console.WriteLine("3. Borrow Book");
                Console.WriteLine("4. Return Book");
                Console.WriteLine("5. View Loans");
                Console.WriteLine("6. View Penalty");
                Console.WriteLine("7. Change Password");
                Console.WriteLine("8. Exit to Main Menu");
                Console.WriteLine("--------------------------------------------------");
                Console.Write("Your choice: ");
                menuchoice = Convert.ToInt32(Console.ReadLine());
            }
            catch (Exception ex)
            {
                // Handling exceptions
                Console.WriteLine(ex.Message);
            }
            finally
            {
                // Processing the member menu choice
                ProcessMemberMenuChoice(menuchoice, member);
            }
        }
        // Process member menu choice
        private static void ProcessMemberMenuChoice(int choice, Member member)
        {
            switch (choice)
            {
                case 1:
                    member.ToString();
                    MemberMenu(member);
                    return;
                case 2:
                    member.ViewAvailableBooks();
                    MemberMenu(member);
                    return;
                case 3:
                    BorrowBookMenu(member);
                    MemberMenu(member);
                    return;
                case 4:
                    ReturnBookMenu(member);
                    MemberMenu(member);
                    return;
                case 5:
                    member.ViewLoanList(member);
                    MemberMenu(member);
                    return;
                case 6:
                    showPenalty(member);
                    MemberMenu(member);
                    return;
                case 7:
                    member.ChangePassword(member);
                    MemberMenu(member);
                    return;
                case 8:
                    Console.WriteLine("Thank you for using this system, {0}, Come Again!!!", member.Name);
                    Program.MainMenu();
                    return;
                default:
                    Console.WriteLine("Invalid choice");
                    MemberMenu(member);
                    break;
            }
        }

        // Borrow book menu function
        private static void BorrowBookMenu(Member member)
        {
            // Checking if the member is valid
            if (member == null)
            {
                Console.WriteLine("Invalid member. Please log in again.");
                return;
            }

            // Displaying available books and prompting for book ID to borrow
            Console.WriteLine("=== Borrow Book ===");
            member.ViewAvailableBooks();
            Console.Write("Enter BookID of Book You Want to Borrow: ");
            string bookid = Console.ReadLine();

            // Borrowing the book
            member.BorrowBook(member.memID, bookid);
        }
        // Return book menu function
        private static void ReturnBookMenu(Member member)
        {
            // Checking if the member is valid
            if (member == null)
            {
                Console.WriteLine("Invalid member. Please log in again.");
                return;
            }

            // Displaying loaned books and prompting for book ID to return
            Console.WriteLine("=== Return Book ===");
            member.ViewLoanList(member);
            Console.Write("Enter BookID of Book You Want to Return: ");
            string bookid = Console.ReadLine();

            // Returning the book
            member.ReturnBook(member.memID, bookid);
        }
        // Show penalty function
        private static void showPenalty(Member member)
        {
            // Checking if the member has loans
            if (member.Loans.Count == 0)
            {
                Console.WriteLine("No loans available for this user.");
            }
            else
            {
                // Displaying loans and prompting for loan ID to show penalty
                Console.WriteLine("=== Show Penalty ===");
                member.ViewLoanList(member);
                Console.Write("Enter Loan ID to show the penalty for that loan: ");
                string loanid = Console.ReadLine();
                member.GetPenalty(member, loanid);
            }
        }
    }
}
