﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace legitassn
{
    public class Book
    {
        public string BookID {  get; set; }
        public string ISBN { get; set; }
        public string Title { get; set; }
        public string Author { get; set; }
        public Boolean  Availability { get; set; }

        public Book(string bookID, string iSBN, string title, string author, bool availability)
        {
            BookID = bookID;
            ISBN = iSBN;
            Title = title;
            Author = author;
            Availability = true;
        }
        // Method to get a formatted string with book details
        public string GetDetails()
        {
            return $"{Title} by {Author} (ISBN: {ISBN})";
        }

        // Method to check the availability of the book
        public bool CheckBookAvailability()
        {
            return Availability;
        }


    }
}
