﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace legitassn
{
    public class Loan
    {
        public string LoanID { get; set; }
        public Member BorrowedMember { get; set; }
        public Book BorrowedBookID { get; set; }

        public Book BorrowedBookTitle { get; set; }
        public DateTime DueDate { get; set; }

        public Loan(string LoanID, string MemberID, string BookID, DateTime DueDate)
        {
            this.LoanID = LoanID;

            // Find the BorrowedMember using the provided MemberID
            BorrowedMember = Library.members.Find(m => m.memID == MemberID);

            // Find the BorrowedBookID using the provided BookID
            BorrowedBookID = Library.books.Find(b => b.BookID == BookID);

            this.DueDate = DueDate;

            // Check if BorrowedMember or BorrowedBookID is null and display a message if not found
            if (BorrowedMember == null)
            {
                Console.WriteLine($"Member '{MemberID}' not found in the library.");
            }

            if (BorrowedBookID == null)
            {
                Console.WriteLine($"Book with ID '{BookID}' not found in the library.");
            }
        }

    }
}
