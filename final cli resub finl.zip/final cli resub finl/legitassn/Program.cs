﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.Remoting.Services;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace legitassn
{
    class Program
    {
        public static Library library = new Library();
        static void Main(string[] args)
        {
            library.LoadData();
            MainMenu();
            library.SaveData();
        }
        //Main Menu
        public static void MainMenu()
        {
            int menuchoice = 0;
            try
            {
                Console.WriteLine("=== Welcome to the Library! ===");
                Console.WriteLine("Select User Type:");
                Console.WriteLine("1. Member");
                Console.WriteLine("2. Librarian");
                Console.WriteLine("3. Exit");
                Console.Write("Enter your choice: ");
                menuchoice = Convert.ToInt32(Console.ReadLine());
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                Console.WriteLine("Exceptions Handled");

                ProcessMainMenuChoice(menuchoice);
            }
        }

        //Retrieveing necessary menu
        private static void ProcessMainMenuChoice(int choice)
        {
            switch (choice)
            {
                case 1:
                    Member_UI.MemberLogin();
                    break;
                case 2:
                    Librarian_UI.LibrarianLogin();
                    break;
                case 3:
                    Console.ReadKey();
                    break;
                default:
                    Console.WriteLine("Invalid choice");
                    break;
            }
        }

    }

}

    
        





