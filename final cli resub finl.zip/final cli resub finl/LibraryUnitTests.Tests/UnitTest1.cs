using legitassn;
using Microsoft.VisualStudio.TestPlatform.Utilities;
using Xunit;
namespace LibraryUnitTests.Tests;
public class UnitTest1
{
    [Fact]
    public void ValidateMemberLogin_ValidCredentials()
    {
        string memberID = "MEM001";
        string password = "117";
        string name = "John";
        string address = "UNSC";
        DateTime dateOfBirth = new DateTime(2000, 1, 1);
        List<Loan> borrowedbooks = new List<Loan>();

        // Act
        Member newMember = new Member(memberID, password, name, dateOfBirth, address, borrowedbooks);
        Member result = Member_UI.ValidateMemberLogin(memberID, password);

        // Assert
        Assert.Equal(memberID, newMember.memID);
        Assert.Equal(password, newMember.password);
    }

    [Fact]
    public void ValidateMemberLogin_InvalidCredentials()
    {
        // Arrange
        string memberID = "MEM001";
        string password = "117";
        string name = "John";
        string address = "UNSC";
        DateTime dateOfBirth = new DateTime(2000, 1, 1);
        List<Loan> borrowedbooks = new List<Loan>();

        // Act
        Member newMember = new Member(memberID, password, name, dateOfBirth, address, borrowedbooks);
        Member result = Member_UI.ValidateMemberLogin("MEM001", "Deez");

        // Assert
        Assert.Null(result);
    }

    [Fact]
    public void RemoveMember()
    {
        Library library = new Library();
        string memberID = "MEM001";
        string password = "117";
        string name = "John";
        string address = "UNSC";
        DateTime dateOfBirth = new DateTime(2000, 1, 1);
        List<Loan> borrowedbooks = new List<Loan>();

        library.AddMember(memberID, password, name, dateOfBirth, address);

        library.RemoveMember(memberID);


    }

    [Fact]
    public void RemoveBook()
    {
        // Arrange
        Library library = new Library();
        string bookId = "B001";
        string isbn = "1234567890";
        string title = "Sample Book";
        string author = "John Author";

        // Act
        library.AddBook(bookId, isbn, title, author);
        Book bookRemove = Library.books.Find(b => b.BookID == bookId);
        library.RemoveBook(bookId);

        Assert.DoesNotContain(bookRemove, Library.books);

    }

    [Fact]
    public void AddLibrarian()
    {

        string librarianID = "L001";
        string librarianPwd = "password123";
        string name = "John Doe";
        DateTime dateOfBirth = new DateTime(1990, 1, 1);
        string address = "123 Main St";
        double salaryRate = 20.50;
        int workHours = 40;

        Librarian librarian = new Librarian(librarianID, librarianPwd, name, dateOfBirth, address, salaryRate, workHours);

        Assert.Equal(librarianID, librarian.LibrarianID);
        Assert.Equal(librarianPwd, librarian.LibrarianPwd);
        Assert.Equal(name, librarian.Name);
        Assert.Equal(dateOfBirth, librarian.DOB);
        Assert.Equal(address, librarian.Address);
        Assert.Equal(salaryRate, librarian.SalaryRate);
        Assert.Equal(workHours, librarian.WorkHours);
    }

    [Fact]

    public void ValidateLibrarianLogin_ValidCredentials()
    {
        string librarianID = "L001";
        string librarianPwd = "password123";
        string name = "John Doe";
        DateTime dateOfBirth = new DateTime(1990, 1, 1);
        string address = "123 Main St";
        double salaryRate = 20.50;
        int workHours = 40;

        // Act
        Librarian librarian = new Librarian(librarianID, librarianPwd, name, dateOfBirth, address, salaryRate, workHours);
        Librarian result = Librarian_UI.ValidateLibrarianLogin(librarianID, librarianPwd);

        // Assert
        Assert.Equal(librarianID, librarian.LibrarianID);
        Assert.Equal(librarianPwd, librarian.LibrarianPwd);
    }

    [Fact]
    public void ValidateLibrarianLogin_InvalidCredentials()
    {
        string librarianID = "L001";
        string librarianPwd = "password123";
        string name = "John Doe";
        DateTime dateOfBirth = new DateTime(1990, 1, 1);
        string address = "123 Main St";
        double salaryRate = 20.50;
        int workHours = 40;

        // Act
        Librarian librarian = new Librarian(librarianID, librarianPwd, name, dateOfBirth, address, salaryRate, workHours);
        Librarian result = Librarian_UI.ValidateLibrarianLogin(librarianID, librarianPwd);


        Assert.Null(result);
    }

    [Fact]
    public void AddBook()
    {

        Library library = new Library();
        string bookId = "B001";
        string isbn = "1234567890";
        string title = "Sample Book";
        string author = "John Author";

        // Act
        library.AddBook(bookId, isbn, title, author);
        Book book = Library.books.Find(b => b.BookID == bookId);
        // Assert
        Assert.Contains(book, Library.books);
    }

    [Fact]

    public void BorrowBookSuccessfully()
    {
        // Arrange
        Library library = new Library();
        string memberId = "M001";
        string memberPwd = "password123";
        string memberName = "John Doe";
        DateTime memberDOB = new DateTime(1990, 1, 1);
        string memberAddress = "123 Main St";

        library.AddMember(memberId, memberPwd, memberName, memberDOB, memberAddress);
        library.AddBook("B001", "1234567890", "Sample Book", "John Author");

        Member member = Library.members.Find(m => m.memID == memberId);
        string bookId = "B001";

        // Act
        member.BorrowBook(memberId, bookId);

        // Assert
        Book borrowedBook = Library.books.Find(b => b.BookID == bookId);
        Assert.False(borrowedBook.Availability);
        Assert.Equal(1, member.Loans.Count);
    }

    [Fact]

    public void BorrowBookBookNotFound()
    {
        // Arrange
        Library library = new Library();
        string memberId = "M001";
        string memberPwd = "password123";
        string memberName = "John Doe";
        DateTime memberDOB = new DateTime(1990, 1, 1);
        string memberAddress = "123 Main St";

        library.AddMember(memberId, memberPwd, memberName, memberDOB, memberAddress);
        library.AddBook("B001", "1234567890", "Sample Book", "John Author");

        Member member = Library.members.Find(m => m.memID == memberId);
        string bookId = "B111";

        // Act
        member.BorrowBook(memberId, bookId);


        Assert.Equal(0, member.Loans.Count);
    }

    [Fact]

    public void BorrowBookBookNotAvailable()
    {
        // Arrange
        Library library = new Library();
        string memberId = "M001";
        string memberPwd = "password123";
        string memberName = "John Doe";
        DateTime memberDOB = new DateTime(1990, 1, 1);
        string memberAddress = "123 Main St";

        library.AddMember(memberId, memberPwd, memberName, memberDOB, memberAddress);
        library.AddBook("B001", "1234567890", "Sample Book", "John Author");

        Member member = Library.members.Find(m => m.memID == memberId);
        string bookId = "B001";

        // Borrow the book once
        member.BorrowBook(memberId, bookId);

        // Act
        member.BorrowBook(memberId, bookId);

        // Assert
        Assert.Equal(1, member.Loans.Count);
    }
    [Fact]
    public void ReturnBookSuccessfully()
    {
        // Arrange
        Library library = new Library();
        string memberId = "M001";
        string memberPwd = "password123";
        string memberName = "John Doe";
        DateTime memberDOB = new DateTime(1990, 1, 1);
        string memberAddress = "123 Main St";

        library.AddMember(memberId, memberPwd, memberName, memberDOB, memberAddress);
        library.AddBook("B001", "1234567890", "Sample Book", "John Author");

        Member member = Library.members.Find(m => m.memID == memberId);
        string bookId = "B001";

        // Borrow the book
        member.BorrowBook(memberId, bookId);

        // Act
        member.ReturnBook(memberId, bookId);

        // Assert
        Book returnedBook = Library.books.Find(b => b.BookID == bookId);
        Assert.True(returnedBook.Availability);
        Assert.Equal(0, member.Loans.Count);
    }

    [Fact]
    public void ReturnBookLoanNotFound()
    {
        // Arrange
        Library library = new Library();
        string memberId = "M001";
        string memberPwd = "password123";
        string memberName = "John Doe";
        DateTime memberDOB = new DateTime(1990, 1, 1);
        string memberAddress = "123 Main St";

        library.AddMember(memberId, memberPwd, memberName, memberDOB, memberAddress);
        library.AddBook("B001", "1234567890", "Sample Book", "John Author");

        Member member = Library.members.Find(m => m.memID == memberId);
        string bookId = "B001"; // Assuming B001 is not borrowed

        // Act
        member.ReturnBook(memberId, bookId);

        // Assert
        Assert.Equal(0, member.Loans.Count);
    }

    [Fact]
    public void ReturnBookBookNotFound()
    {
        // Arrange
        Library library = new Library();
        string memberId = "M001";
        string memberPwd = "password123";
        string memberName = "John Doe";
        DateTime memberDOB = new DateTime(1990, 1, 1);
        string memberAddress = "123 Main St";

        library.AddMember(memberId, memberPwd, memberName, memberDOB, memberAddress);
        library.AddBook("B001", "1234567890", "Sample Book", "John Author");

        Member member = Library.members.Find(m => m.memID == memberId);
        string bookId = "B002"; // Assuming B002 is not in the library

        // Borrow the book
        member.BorrowBook(memberId, "B001");

        // Act
        member.ReturnBook(memberId, bookId);

        // Assert
        Assert.Equal(1, member.Loans.Count);
    }
    [Fact]
    public void CalculatePenaltySuccessfully()
    {
        // Arrange
        Library library = new Library();
        string memberId = "M001";
        string memberPwd = "password123";
        string memberName = "John Doe";
        DateTime memberDOB = new DateTime(1990, 1, 1);
        string memberAddress = "123 Main St";

        library.AddMember(memberId, memberPwd, memberName, memberDOB, memberAddress);
        library.AddBook("B001", "1234567890", "Sample Book", "John Author");

        Member member = Library.members.Find(m => m.memID == memberId);
        string bookId = "B001";

        // Borrow the book
        member.BorrowBook(memberId, bookId);

        // Set Due Date to a past date to simulate an overdue book
        Loan loan = member.Loans[0];
        loan.DueDate = DateTime.Now.AddDays(-7); // Overdue by 7 days

        // Act
        member.getPenalty(member, loan.LoanID);

        // Assert
        Assert.Equal(350.0, member.penaltyfee); // Assuming penalty rate is $50 per day
    }

    [Fact]
    public void CalculatePenaltyBookNotOverdue()
    {
        // Arrange
        Library library = new Library();
        string memberId = "M001";
        string memberPwd = "password123";
        string memberName = "John Doe";
        DateTime memberDOB = new DateTime(1990, 1, 1);
        string memberAddress = "123 Main St";

        library.AddMember(memberId, memberPwd, memberName, memberDOB, memberAddress);
        library.AddBook("B001", "1234567890", "Sample Book", "John Author");

        Member member = Library.members.Find(m => m.memID == memberId);
        string bookId = "B001";

        // Borrow the book
        member.BorrowBook(memberId, bookId);

        // Act
        member.getPenalty(member, member.Loans[0].LoanID);

        // Assert
        Assert.Equal(0.0, member.penaltyfee); // No penalty for a book not overdue
    }

    [Fact]
    public void CalculatePenaltyLoanNotFound()
    {
        // Arrange
        Library library = new Library();
        string memberId = "M001";
        string memberPwd = "password123";
        string memberName = "John Doe";
        DateTime memberDOB = new DateTime(1990, 1, 1);
        string memberAddress = "123 Main St";

        library.AddMember(memberId, memberPwd, memberName, memberDOB, memberAddress);

        Member member = Library.members.Find(m => m.memID == memberId);
        string invalidLoanId = "L5";

        // Act
        member.getPenalty(member, invalidLoanId);

        // Assert
        Assert.Equal(0.0, member.penaltyfee); // No penalty if loan is not found
    }

    [Fact]
    public void AddMember_MemberAlreadyExists_ShouldNotAddDuplicateMember()
    {
        Library library = new Library();
        string existingMemberId = "M001";
        string existingMemberPwd = "M001";
        string name = "John Doe";
        DateTime dateOfBirth = new DateTime(1990, 1, 1);
        string address = "123 Main St";

        // Add an existing member
        library.AddMember(existingMemberId, existingMemberPwd, name, dateOfBirth, address);

        // Act
        var consoleInput = new StringReader($"{existingMemberId}{Environment.NewLine}{existingMemberPwd}{Environment.NewLine}Jane Doe{Environment.NewLine}1995-05-05{Environment.NewLine}456 Oak St{Environment.NewLine}");
        Console.SetIn(consoleInput);

        Librarian_UI.MemberSignUp();

        // Assert
        Member duplicateMember = Library.members.Find(m => m.memID == existingMemberId);
        Assert.Single(Library.members); // Ensure there is only one member (no duplicates)
        Assert.NotNull(duplicateMember);
    }

    [Fact]
    public void AddMember_NewMember_ShouldAddMemberToLibrary()
    {
        // Arrange
        Library library = new Library();
        string newMemberId = "M001";
        string existingMemberPwd = "passwd";
        string name = "John Doe";
        DateTime dateOfBirth = new DateTime(1990, 1, 1);
        string address = "123 Main St";

        // Add an existing member
        library.AddMember(newMemberId, existingMemberPwd, name, dateOfBirth, address);

        // Assert
        Member newMember = Library.members.Find(m => m.memID == newMemberId);
        Assert.Single(Library.members); // Ensure there is only one member
        Assert.NotNull(newMember); // Ensure the new member is present in the library
    }
}


